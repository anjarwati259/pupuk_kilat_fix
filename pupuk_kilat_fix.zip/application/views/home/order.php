
<!DOCTYPE html>
<html lang="zxx">
<head>
  <title>Pupuk Kilat - PT Agrikultur Gemilang Indonesia</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- bootstrap css --> 
  <link rel="icon" type="image/png" href="<?php echo base_url() ?>assets/img/logo/logo AGI.png">
  <link rel="stylesheet" href="css/bootstrap.min.css"> 
  <!-- main css -->
  <!-- <link rel="stylesheet" href="css/style.css"> -->
</head>
<body>
 
<!-- home section -->
  <div class="container-fluit">
      <div class="cooming">
        <img src="<?php echo base_url() ?>assets/img/gambar/cooming.png" alt="" style="padding-top: 10px; height: 100%; width: 100%;">
    </div>
  </div>
</body>
</html>

<!-- ======= Testimoni Section ======= -->
    <section id="portfolio" class="portfolio">
      <div class="container">

        <div class="section-title" data-aos="fade-up">
          <h2>Testimoni <strong>Produk</strong></h2>
        </div>

        <div class="row portfolio-container" data-aos="fade-up">

          <div class="col-lg-6 col-md-6 portfolio-item filter-app">
            <!-- <img src="<?php echo base_url() ?>assets/img/portfolio/portfolio-1.jpg" class="img-fluid" alt=""> -->
              <iframe width="700" height="350" src="https://www.youtube.com/embed/NbxS8vCwLqc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          </div>

          <div class="col-lg-6 col-md-6 portfolio-item filter-app">
            <!-- <img src="<?php echo base_url() ?>assets/img/portfolio/portfolio-1.jpg" class="img-fluid" alt=""> -->
              <iframe width="700" height="350" src="https://www.youtube.com/embed/0pzUEepvIUg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          </div>

          <div class="col-lg-6 col-md-6 portfolio-item filter-app">
            <iframe width="700" height="350" src="https://www.youtube.com/embed/NQN5kB0bj-Y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          </div>

          <div class="col-lg-6 col-md-6 portfolio-item filter-card">
            <iframe width="700" height="350" src="https://www.youtube.com/embed/AYr-O1QYdvc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          </div>
        </div>
      </div>
    </section><!-- End Testimoni Section -->
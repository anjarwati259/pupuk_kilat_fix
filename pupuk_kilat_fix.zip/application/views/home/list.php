<?php include('banner.php'); ?>
<?php include('service.php'); ?>
<?php include('kegunaan.php'); ?>
<?php include('testimoni.php'); ?>
<?php include('cara_order.php'); ?>
<?php include('aktifitas.php'); ?>